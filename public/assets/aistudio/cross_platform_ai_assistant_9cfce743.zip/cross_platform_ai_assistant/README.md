# Cross-Platform AI Device Assistant (Starter)

A transparent, permission-based starter project for an AI assistant that can coordinate supported device actions on Android and desktop systems.

## Included

- `core/agent.py`: shared command router with a small, explicit command allowlist.
- `desktop/desktop_agent.py`: optional desktop adapter for opening URLs/apps, typing text, and clicking with PyAutoGUI.
- `android/`: Kotlin Android starter with a visible activity and an opt-in Accessibility Service skeleton.
- No hidden persistence, stealth monitoring, permission bypass, or remote command server.

## Important limits

There is no single permission or app that grants unrestricted access to every Android version, Windows PC, macOS, and Linux machine. Features vary by OS/version and must be granted locally by the device owner. Android background execution is restricted by the OS. WhatsApp UI automation may break when the app UI changes; use official supported integrations where available. Calls and messages can have real-world effects, so this starter requires explicit local commands and keeps those actions out of the generic automation path.

## Requirements

- Python 3.10+
- Optional desktop automation: `pip install -r requirements.txt`
- Android Studio with a recent Android SDK to build the Android module.

## Run the shared command router

From this directory:

```bash
python -m core.agent
```

Try:
- `help`
- `open_url https://example.com`
- `exit`

The shared router does not execute arbitrary shell commands.

## Run desktop controls (optional)

Install dependencies:

```bash
python -m pip install -r requirements.txt
python desktop/desktop_agent.py
```

Commands:
- `open_url https://example.com`
- `type Hello from my assistant`
- `open_app notepad` (Windows only; opens a named, allowlisted app)
- `help`, `exit`

Desktop automation operates visibly in your logged-in session. Do not run it on a device you do not own or administer. Typing goes to whichever window currently has focus.

## Android starter

Open the `android/` folder in Android Studio. The sample includes:
- a visible app screen;
- a button that opens Android Accessibility settings;
- an Accessibility Service skeleton that can inspect the active window and perform basic global actions after the user explicitly enables it.

It intentionally does not auto-enable Accessibility, hide itself, silently read messages, or send calls/messages. Android's exact build configuration may need updating for the SDK installed on your computer.

## Suggested next steps

1. Build and install the Android app from Android Studio.
2. Enable the service manually in Settings only if you want to test accessibility actions.
3. Add platform-specific features one at a time, with confirmation for consequential actions.
4. If you want an LLM connected, add a provider adapter that never exposes API keys to the client and validates every proposed action against an allowlist.
