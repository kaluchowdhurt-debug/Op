// android/app/src/main/java/com/example/deviceassistant/AssistantAccessibilityService.kt
package com.example.deviceassistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Minimal, opt-in accessibility foundation.
 * This sample does not transmit screen content or perform actions automatically.
 */
class AssistantAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Keep event processing local and minimal; add only user-requested workflows.
    }

    override fun onInterrupt() {
        // The system may interrupt accessibility feedback or interactions.
    }

    fun showEnabledStatus() {
        Toast.makeText(this, "Accessibility service is enabled by the user.", Toast.LENGTH_SHORT).show()
    }

    fun performBackForExplicitWorkflow(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun activeWindowRoot(): AccessibilityNodeInfo? = rootInActiveWindow
}
